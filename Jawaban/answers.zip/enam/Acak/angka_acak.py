from random import randint

def acak_bos():
  print(randint(0,100))