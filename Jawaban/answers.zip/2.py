batas_bawah = int(input("Masukkan tahun batas bawah : "))
batas_atas = int(input("Masukkan tahun batas atas : "))

tahun_kabisat = [tahun for tahun in range(batas_bawah, batas_atas) if tahun % 4 == 0]
print(tahun_kabisat)