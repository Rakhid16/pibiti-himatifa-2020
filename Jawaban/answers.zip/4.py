kamus = {"elephant" : "gajah",
         "zebra" : "zebra",
         "dog" : "anjing"}

kata = input("Masukan kata berbahasa inggris : ")

if kata in kamus:
  print("Terjemahan dari " + kata + " adalah " + kamus[kata])
else:
  print("Kata tersebt beluma ada di kamus")